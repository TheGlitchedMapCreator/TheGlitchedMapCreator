param(
    [Parameter(Mandatory = $true)][string]$FilePath,
    [string]$StudioTitle = "My Giant Taco"
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class ImporterMouse {
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int command);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
    [DllImport("user32.dll")] public static extern void mouse_event(uint flags, uint dx, uint dy, uint data, UIntPtr extra);
    public static void Click(int x, int y) {
        SetCursorPos(x, y);
        System.Threading.Thread.Sleep(80);
        mouse_event(2, 0, 0, 0, UIntPtr.Zero);
        mouse_event(4, 0, 0, 0, UIntPtr.Zero);
    }
}
"@

function Get-Condition($property, $value) {
    return New-Object System.Windows.Automation.PropertyCondition($property, $value)
}

function Wait-ForElement($root, $scope, $condition, $timeoutSeconds = 10) {
    $until = [DateTime]::UtcNow.AddSeconds($timeoutSeconds)
    while ([DateTime]::UtcNow -lt $until) {
        $element = $root.FindFirst($scope, $condition)
        if ($element) { return $element }
        Start-Sleep -Milliseconds 200
    }
    return $null
}

function Click-Element($element) {
    $rect = $element.Current.BoundingRectangle
    if ($rect.Width -le 0 -or $rect.Height -le 0) { throw "Control '$($element.Current.Name)' has no visible bounds." }
    [ImporterMouse]::Click([int]($rect.X + $rect.Width / 2), [int]($rect.Y + $rect.Height / 2))
}

function Invoke-Element($element) {
    try {
        $element.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
    } catch {
        try {
            $element.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern).Select()
        } catch {
            Click-Element $element
        }
    }
    Start-Sleep -Milliseconds 150
    [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")
}

function Get-ForegroundProcessId {
    [uint32]$processId = 0
    [ImporterMouse]::GetWindowThreadProcessId([ImporterMouse]::GetForegroundWindow(), [ref]$processId) | Out-Null
    return [int]$processId
}

if (-not [IO.Path]::IsPathRooted($FilePath)) { throw "FilePath must be absolute." }
if ([IO.Path]::GetExtension($FilePath).ToLowerInvariant() -notin @(".glb", ".gltf")) { throw "Only .glb and .gltf files are supported." }
if (-not (Test-Path -LiteralPath $FilePath -PathType Leaf)) { throw "File not found: $FilePath" }

$studioProcesses = @(Get-Process RobloxStudioBeta -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 })
$studio = @($studioProcesses | Where-Object { $_.MainWindowTitle -like "*$StudioTitle*" })
if ($studio.Count -eq 0 -and $studioProcesses.Count -eq 1 -and $studioProcesses[0].MainWindowTitle -match "(?i)RobloxStudio") {
    $studio = $studioProcesses
}
if ($studio.Count -ne 1) { throw "Expected one open Roblox Studio window matching '$StudioTitle'; found $($studio.Count)." }
$studioPid = $studio[0].Id
$foregroundPid = Get-ForegroundProcessId
if ($foregroundPid -ne $studioPid) {
    [ImporterMouse]::ShowWindow($studio[0].MainWindowHandle, 9) | Out-Null
    [ImporterMouse]::SetForegroundWindow($studio[0].MainWindowHandle) | Out-Null
    $until = [DateTime]::UtcNow.AddSeconds(20)
    while ((Get-ForegroundProcessId) -ne $studioPid -and [DateTime]::UtcNow -lt $until) { Start-Sleep -Milliseconds 200 }
}
if ((Get-ForegroundProcessId) -ne $studioPid) { throw "Roblox Studio could not be focused. Bring the matching Studio window to the front and retry." }
$studioRoot = [System.Windows.Automation.AutomationElement]::FromHandle($studio[0].MainWindowHandle)
$previewDialog = $studioRoot.FindFirst([System.Windows.Automation.TreeScope]::Children, (Get-Condition ([System.Windows.Automation.AutomationElement]::NameProperty) "Import Preview"))
$previewAlreadyOpen = $null -ne $previewDialog
if (-not $previewAlreadyOpen) {
    $fileMenu = Wait-ForElement $studioRoot ([System.Windows.Automation.TreeScope]::Descendants) (Get-Condition ([System.Windows.Automation.AutomationElement]::NameProperty) "File")
    if (-not $fileMenu) { throw "Could not find Studio's File menu." }
    $state = $fileMenu.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Current.ExpandCollapseState
    if ($state -eq [System.Windows.Automation.ExpandCollapseState]::Collapsed) {
        $fileMenu.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Expand()
    }
    $importItem = Wait-ForElement $studioRoot ([System.Windows.Automation.TreeScope]::Descendants) (Get-Condition ([System.Windows.Automation.AutomationElement]::NameProperty) "Import")
    if (-not $importItem) { throw "Could not find File > Import." }
    Invoke-Element $importItem

    $desktop = [System.Windows.Automation.AutomationElement]::RootElement
    $openDialog = $null
    $dialogDeadline = [DateTime]::UtcNow.AddSeconds(15)
    while (-not $openDialog -and [DateTime]::UtcNow -lt $dialogDeadline) {
        $topWindows = $desktop.FindAll([System.Windows.Automation.TreeScope]::Children, (Get-Condition ([System.Windows.Automation.AutomationElement]::ControlTypeProperty) ([System.Windows.Automation.ControlType]::Window)))
        foreach ($window in $topWindows) {
            if ($window.Current.Name -match "(?i)(3D File|GLB|GLTF|FBX|OBJ)") { $openDialog = $window; break }
        }
        if (-not $openDialog) { Start-Sleep -Milliseconds 200 }
    }
    if (-not $openDialog) {
        $visibleWindows = @()
        $topWindows = $desktop.FindAll([System.Windows.Automation.TreeScope]::Children, (Get-Condition ([System.Windows.Automation.AutomationElement]::ControlTypeProperty) ([System.Windows.Automation.ControlType]::Window)))
        foreach ($window in $topWindows) { if ($window.Current.Name) { $visibleWindows += $window.Current.Name } }
        $itemRect = $importItem.Current.BoundingRectangle
        $itemInfo = "Import control: type=$($importItem.Current.ControlType.ProgrammaticName), id=$($importItem.Current.AutomationId), offscreen=$($importItem.Current.IsOffscreen), bounds=$($itemRect.X),$($itemRect.Y),$($itemRect.Width),$($itemRect.Height)"
        throw ("Studio did not open its 3D file picker. " + $itemInfo + ". Visible windows: " + ($visibleWindows -join " | "))
    }
    if ((Get-ForegroundProcessId) -ne $studioPid) { throw "Studio's file picker is not active. Bring it to the front and retry." }

    # The standard Windows file picker accepts an absolute path in its File name field.
    [System.Windows.Forms.SendKeys]::SendWait("%n")
    Start-Sleep -Milliseconds 150
    [System.Windows.Forms.Clipboard]::SetText($FilePath)
    [System.Windows.Forms.SendKeys]::SendWait("^a")
    [System.Windows.Forms.SendKeys]::SendWait("^v")
    [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")
}

# Studio's "Import Preview" panel renders its contents (settings, checkboxes,
# the Import button) through its own internal engine widget. That widget
# exposes zero child controls to UI Automation - no Button, no CheckBox - so
# searching the control tree for them (as earlier versions of this script
# did) can never find anything there, no matter how broadly it searches.
# The dialog window itself IS a real, UIA-addressable window though, so we
# drive its contents by clicking fixed pixel offsets inside its bounding
# rect and by sampling pixel colors to read checkbox/button state.
function Get-RegionAverageColor([int]$cx, [int]$cy, [int]$half = 7) {
    # Single-pixel sampling is too fragile against a tiny checkmark glyph -
    # a 1px miss reads as background. Average a small region around the
    # target instead: a checked box (glyph ink covers a meaningful share of
    # the box) averages far from white even if we're a few px off-center.
    #
    # CopyFromScreen with a small, non-zero source offset reads back stale
    # (near-black) data on this session unless Studio's window was *just*
    # re-foregrounded - the display only repaints on an activation event.
    # Re-foreground first, then capture the whole virtual screen (which does
    # read live) and crop the region out of that in-memory bitmap instead of
    # grabbing the small region directly from the screen.
    [ImporterMouse]::ShowWindow($studio[0].MainWindowHandle, 9) | Out-Null
    [ImporterMouse]::SetForegroundWindow($studio[0].MainWindowHandle) | Out-Null
    Start-Sleep -Milliseconds 200

    $bounds = [System.Windows.Forms.SystemInformation]::VirtualScreen
    $full = New-Object System.Drawing.Bitmap($bounds.Width, $bounds.Height)
    $g = [System.Drawing.Graphics]::FromImage($full)
    $g.CopyFromScreen($bounds.Location, [System.Drawing.Point]::Empty, $bounds.Size)
    $g.Dispose()

    $bx = $cx - $bounds.X
    $by = $cy - $bounds.Y
    $sumR = 0; $sumG = 0; $sumB = 0; $count = 0
    for ($px = $bx - $half; $px -lt $bx + $half; $px++) {
        for ($py = $by - $half; $py -lt $by + $half; $py++) {
            $c = $full.GetPixel($px, $py)
            $sumR += $c.R; $sumG += $c.G; $sumB += $c.B
            $count++
        }
    }
    $full.Dispose()
    return [PSCustomObject]@{ R = $sumR / $count; G = $sumG / $count; B = $sumB / $count }
}

function Test-CheckboxChecked([int]$x, [int]$y) {
    # Measured: checked box glyph averages ~(52,54,58); unchecked averages
    # ~(252,252,252) (plain white background). 200 sits well clear of both.
    $c = Get-RegionAverageColor $x $y 7
    return ($c.R -lt 200 -or $c.G -lt 200 -or $c.B -lt 200)
}

$previewDeadline = [DateTime]::UtcNow.AddSeconds(30)
while (-not $previewDialog -and [DateTime]::UtcNow -lt $previewDeadline) {
    $studioRoot = [System.Windows.Automation.AutomationElement]::FromHandle($studio[0].MainWindowHandle)
    $previewDialog = $studioRoot.FindFirst([System.Windows.Automation.TreeScope]::Children, (Get-Condition ([System.Windows.Automation.AutomationElement]::NameProperty) "Import Preview"))
    if (-not $previewDialog) { Start-Sleep -Milliseconds 250 }
}
if (-not $previewDialog) { throw "Studio did not show its Import Preview panel after selecting the GLB. The file may have been rejected." }

$rect = $previewDialog.Current.BoundingRectangle
if ($rect.Width -le 0 -or $rect.Height -le 0) { throw "Import Preview panel has no visible bounds." }

# Offsets measured against Studio's native 800x730 Import Preview layout,
# scaled to whatever size the dialog actually reports (DPI/display variance).
$scaleX = $rect.Width / 800.0
$scaleY = $rect.Height / 730.0
$uploadToRobloxPoint = @([int]($rect.X + 588 * $scaleX), [int]($rect.Y + 174 * $scaleY))
$addToWorkspacePoint = @([int]($rect.X + 588 * $scaleX), [int]($rect.Y + 250 * $scaleY))
$importButtonPoint = @([int]($rect.X + 715 * $scaleX), [int]($rect.Y + 690 * $scaleY))

# Do not publish this model as a Roblox asset. Keep it in the place's Workspace only.
# (800ms post-click pause: the custom-rendered checkbox glyph redraws on its
# own cycle and a short pause can sample stale pixels.)
if (Test-CheckboxChecked $uploadToRobloxPoint[0] $uploadToRobloxPoint[1]) {
    [ImporterMouse]::Click($uploadToRobloxPoint[0], $uploadToRobloxPoint[1])
    Start-Sleep -Milliseconds 800
    if (Test-CheckboxChecked $uploadToRobloxPoint[0] $uploadToRobloxPoint[1]) { throw "Could not turn off 'Upload to Roblox'; refusing to continue." }
}
if (-not (Test-CheckboxChecked $addToWorkspacePoint[0] $addToWorkspacePoint[1])) {
    [ImporterMouse]::Click($addToWorkspacePoint[0], $addToWorkspacePoint[1])
    Start-Sleep -Milliseconds 800
    if (-not (Test-CheckboxChecked $addToWorkspacePoint[0] $addToWorkspacePoint[1])) {
        $debugColor = Get-RegionAverageColor $addToWorkspacePoint[0] $addToWorkspacePoint[1] 7
        throw ("Could not enable 'Add to Workspace'; refusing to continue. Preview bounds=$($rect.X),$($rect.Y),$($rect.Width),$($rect.Height); sample point=$($addToWorkspacePoint[0]),$($addToWorkspacePoint[1]); RGB=$([Math]::Round($debugColor.R)),$([Math]::Round($debugColor.G)),$([Math]::Round($debugColor.B)).")
    }
}

# Wait for parsing to finish: the enabled Import button is saturated blue.
$importReady = $false
$parseDeadline = [DateTime]::UtcNow.AddSeconds(120)
while ([DateTime]::UtcNow -lt $parseDeadline) {
    $current = Get-RegionAverageColor $importButtonPoint[0] $importButtonPoint[1] 10
    if ($current.B -gt 180 -and $current.B -gt ($current.R * 1.3) -and $current.G -gt ($current.R * 1.1)) { $importReady = $true; break }
    Start-Sleep -Milliseconds 500
}
if (-not $importReady) { throw "Studio's Import button never looked enabled after parsing (timed out after 120s). The file may have been rejected or needs manual review." }

[ImporterMouse]::Click($importButtonPoint[0], $importButtonPoint[1])
Start-Sleep -Seconds 2
Write-Output ("Clicked Studio Import for {0}. Upload to Roblox was left off; verify the imported model in Workspace." -f [IO.Path]::GetFileName($FilePath))
