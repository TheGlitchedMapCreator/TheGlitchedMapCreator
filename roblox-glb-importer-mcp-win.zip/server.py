"""Small stdio MCP server for importing local GLB/GLTF files through Studio's UI."""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
IMPORT_SCRIPT = ROOT / "import_glb.ps1"
POWERSHELL = os.environ.get("ROBLOX_IMPORT_POWERSHELL", "powershell.exe")
MAX_FILE_BYTES = 100 * 1024 * 1024


def write_message(message: dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(message, separators=(",", ":")) + "\n")
    sys.stdout.flush()


def text_result(text: str, is_error: bool = False) -> dict[str, Any]:
    return {"content": [{"type": "text", "text": text}], "isError": is_error}


def import_local_glb(arguments: dict[str, Any]) -> dict[str, Any]:
    file_path = arguments.get("file_path")
    studio_title = arguments.get("studio_title", "Roblox Studio")
    if not isinstance(file_path, str) or not file_path.strip():
        return text_result("file_path must be an absolute path to a local .glb or .gltf file.", True)
    path = Path(file_path).expanduser()
    if not path.is_absolute():
        return text_result("file_path must be absolute.", True)
    if path.suffix.lower() not in {".glb", ".gltf"}:
        return text_result("Only .glb and .gltf files are supported.", True)
    if not path.is_file():
        return text_result(f"File not found: {path}", True)
    if path.stat().st_size > MAX_FILE_BYTES:
        return text_result("Studio's local importer accepts files up to 100 MB.", True)
    if not isinstance(studio_title, str) or not studio_title.strip():
        return text_result("studio_title must be a non-empty window-title fragment.", True)

    command = [
        POWERSHELL,
        "-NoLogo",
        "-NoProfile",
        "-STA",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        str(IMPORT_SCRIPT),
        "-FilePath",
        str(path),
        "-StudioTitle",
        studio_title,
    ]
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=180, check=False)
    except subprocess.TimeoutExpired:
        return text_result("Studio's importer did not finish within 180 seconds. Check the open Studio window and try again.", True)
    except OSError as error:
        return text_result(f"Could not start the Windows UI helper: {error}", True)

    output = "\n".join(part.strip() for part in (result.stdout, result.stderr) if part.strip())
    if result.returncode:
        return text_result(output or f"Studio import failed with exit code {result.returncode}.", True)
    return text_result(output or f"Import was submitted for {path.name}. Check Workspace in Studio.")


TOOLS = [
    {
        "name": "import_local_glb",
        "title": "Import local GLB into Roblox Studio",
        "description": (
            "Import a local .glb or .gltf file into the selected open Roblox Studio place using Studio's native 3D Importer. "
            "This drives the Studio UI, so the matching Studio window must be open and available. "
            "The helper refuses to continue unless it can disable 'Upload to Roblox'; the model is intended for Workspace only."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Absolute local path to the .glb or .gltf file.",
                },
                "studio_title": {
                    "type": "string",
                    "description": "A unique fragment of the target Roblox Studio window title. Defaults to 'Roblox Studio'.",
                    "default": "Roblox Studio",
                },
            },
            "required": ["file_path"],
            "additionalProperties": False,
        },
    }
]


def handle(request: dict[str, Any]) -> dict[str, Any] | None:
    method = request.get("method")
    request_id = request.get("id")
    if method == "notifications/initialized" or method == "notifications/cancelled":
        return None
    if method == "initialize":
        params = request.get("params") or {}
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {
                "protocolVersion": params.get("protocolVersion", "2025-03-26"),
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {"name": "roblox-local-glb-importer", "version": "1.0.0"},
                "instructions": "Use import_local_glb with an absolute local path. This server uses Roblox Studio's visible native importer UI and does not publish the asset to Roblox.",
            },
        }
    if method == "ping":
        return {"jsonrpc": "2.0", "id": request_id, "result": {}}
    if method == "tools/list":
        return {"jsonrpc": "2.0", "id": request_id, "result": {"tools": TOOLS}}
    if method == "tools/call":
        params = request.get("params") or {}
        if params.get("name") != "import_local_glb":
            result = text_result(f"Unknown tool: {params.get('name')}", True)
        else:
            arguments = params.get("arguments") or {}
            result = import_local_glb(arguments if isinstance(arguments, dict) else {})
        return {"jsonrpc": "2.0", "id": request_id, "result": result}
    if request_id is not None:
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {"code": -32601, "message": f"Method not found: {method}"},
        }
    return None


def main() -> int:
    for line in sys.stdin:
        request: Any = None
        try:
            request = json.loads(line)
            if not isinstance(request, dict):
                continue
            response = handle(request)
            if response is not None:
                write_message(response)
        except Exception as error:  # Keep diagnostics off stdout, which is the MCP transport.
            print(f"MCP request failed: {error}", file=sys.stderr, flush=True)
            request_id = request.get("id") if isinstance(request, dict) else None
            if request_id is not None:
                write_message({"jsonrpc": "2.0", "id": request_id, "error": {"code": -32603, "message": "Internal server error"}})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
