# Roblox Local GLB Importer MCP

A Windows MCP server that imports a local `.glb` or `.gltf` file into an open Roblox Studio place using Studio's native Import Preview window.

## Requirements

- Windows 10 or 11 with Roblox Studio installed
- Python 3.10 or newer available as `py.exe`
- Codex desktop installed on the same Windows computer

## Install on another Windows computer

1. Download this repository as a ZIP from GitHub and extract it to a permanent folder, such as `C:\Roblox\roblox-glb-importer-mcp`.
2. Confirm Python is available by running `py -3 --version` in PowerShell.
3. Open `%USERPROFILE%\.codex\config.toml` and add the MCP entry below. Replace the example server path with the absolute path to the extracted `server.py`.

```toml
[mcp_servers.Roblox_Local_GLB_Importer]
command = "py.exe"
args = ["-3", "C:\\Roblox\\roblox-glb-importer-mcp\\server.py"]
startup_timeout_sec = 120
```

4. Restart Codex or open a fresh task so it loads the new server.
5. Open the target place in Roblox Studio and call `import_local_glb` with an absolute `.glb` or `.gltf` path. The optional `studio_title` defaults to `Roblox Studio`; set it to a unique title fragment if more than one Studio window is open.

## What the tool does

The helper drives Studio's visible Import Preview window, disables **Upload to Roblox**, enables **Add to Workspace**, and clicks **Import** only after verifying those settings. It does not publish the model as an asset. The Studio window must be open in the same interactive Windows session.

The tool accepts files up to 100 MB. Its only dependency is the Python standard library; the UI helper uses Windows PowerShell and UI Automation.

## Troubleshooting

- Keep the target Studio place open and visible while importing.
- If multiple Studio windows are open, provide a unique `studio_title` fragment.
- If Studio changes its Import Preview layout, the helper can stop rather than import with unverified settings. Update the coordinate checks in `import_glb.ps1` for the new layout.
